import numpy as np
import pandas as pd

np.random.seed(42)

ROWS = 30001

# -----------------------------
# Patient ID
# -----------------------------
patient_id = np.arange(1, ROWS + 1)

# -----------------------------
# Age
# -----------------------------
age = np.random.normal(53.56, 20.78, ROWS)
age = np.clip(np.round(age), 18, 89).astype(int)

# -----------------------------
# Gender
# -----------------------------
gender = np.random.choice(
    ["Male", "Female"],
    size=ROWS,
    p=[0.6947, 0.3053]
)

# -----------------------------
# Smoking Status
# -----------------------------
smoking_status = np.random.choice(
    ["Current", "Never", "Former"],
    size=ROWS,
    p=[0.6011, 0.2471, 0.1518]
)

# -----------------------------
# Years of Smoking
# -----------------------------
years = []

for status, a in zip(smoking_status, age):

    if status == "Never":
        years.append(0)

    elif status == "Former":
        value = np.random.normal(15, 8)
        value = max(1, min(value, a - 18))
        years.append(round(value))

    else:
        value = np.random.normal(18, 9)
        value = max(1, min(value, a - 18))
        years.append(round(value))

years = np.array(years)

years = np.clip(years, 0, 39)

# -----------------------------
# Cigarettes Per Day
# -----------------------------
cigarettes = []

for status in smoking_status:

    if status == "Never":
        cigarettes.append(0)

    elif status == "Former":
        cigarettes.append(
            np.random.randint(5, 21)
        )

    else:
        cigarettes.append(
            np.random.randint(10, 41)
        )

cigarettes = np.array(cigarettes)

# -----------------------------
# Organ
# -----------------------------
organ = np.random.choice(
    ["Heart", "Kidney", "Lungs", "Liver"],
    ROWS,
    p=[0.5028, 0.2470, 0.1521, 0.0981]
)

# -----------------------------
# Organ Condition
# -----------------------------
condition = np.random.choice(
    ["Damaged", "Healthy"],
    ROWS,
    p=[0.5879, 0.4121]
)

# -----------------------------
# BMI
# -----------------------------
bmi = np.random.normal(
    29.46,
    7.21,
    ROWS
)

bmi = np.clip(
    bmi,
    17,
    42
)

bmi = np.round(
    bmi,
    1
)

# -----------------------------
# BP Risk
# -----------------------------
bp = np.random.choice(
    ["High", "Normal", "Low"],
    ROWS,
    p=[0.5491, 0.3040, 0.1469]
)

# -----------------------------
# Cholesterol
# -----------------------------
cholesterol = np.random.normal(
    209.66,
    52.17,
    ROWS
)

cholesterol = np.clip(
    cholesterol,
    120,
    300
)

cholesterol = np.round(
    cholesterol
).astype(int)

# -----------------------------
# Family History
# -----------------------------
family = np.random.choice(
    ["Yes", "No"],
    ROWS,
    p=[0.6977, 0.3023]
)

# -----------------------------
# Alcohol
# -----------------------------
alcohol = np.random.choice(
    ["High", "Moderate", "Low"],
    ROWS,
    p=[0.4982, 0.3067, 0.1951]
)

# -----------------------------
# DataFrame
# -----------------------------
smoking = pd.DataFrame({

    "Patient_ID": patient_id,

    "Age": age,

    "Gender": gender,

    "Smoking_Status": smoking_status,

    "Years_of_Smoking": years,

    "Cigarettes_Per_Day": cigarettes,

    "Organ": organ,

    "Organ_Condition": condition,

    "BMI": bmi,

    "BP_Risk": bp,

    "Cholesterol_Level": cholesterol,

    "Family_History_Risk": family,

    "Alcohol_Consumption": alcohol

})
# ======================================
# Cancer Diagnosis
# ======================================

cancer_diagnosis = np.random.choice(
    ["Yes", "No"],
    size=ROWS,
    p=[0.30, 0.70]
)

# ======================================
# Cancer Type
# ======================================

cancer_type = []

for diagnosis in cancer_diagnosis:

    if diagnosis == "No":

        cancer_type.append("None")

    else:

        cancer_type.append(
            np.random.choice(
                [
                    "Lung Cancer",
                    "Oral Cancer",
                    "Throat Cancer",
                    "Bladder Cancer"
                ],
                p=[
                    0.60,
                    0.20,
                    0.10,
                    0.10
                ]
            )
        )

cancer = pd.DataFrame({

    "Patient_ID": patient_id,

    "Cancer_Diagnosis": cancer_diagnosis,

    "Cancer_Type": cancer_type

})
# ======================================
# Save Files
# ======================================

smoking.to_csv(
    "Smoking_Dataset.csv",
    index=False
)

cancer.to_excel(
    "Cancer_Dataset.xlsx",
    index=False
)

print("=" * 50)
print("Datasets Generated Successfully")
print("=" * 50)

print("\nSmoking Dataset")
print(smoking.head())

print("\nCancer Dataset")
print(cancer.head())